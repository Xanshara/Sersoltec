<?php
/**
 * SERSOLTEC v2.4 - Admin Reviews Management
 * Sprint 2.3: Reviews System
 * 
 * Admin panel for moderating product reviews
 * Location: /admin/reviews.php
 */

session_start();
require_once '../config.php';

// Check if admin is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: /login.php');
    exit;
}

// Set timezone
date_default_timezone_set('Europe/Warsaw');

// Get database connection
try {
    $host = DB_HOST ?? 'localhost';
    $dbname = DB_NAME ?? 'sersoltec_db';
    $user = DB_USER ?? 'sersoltec';
    $pass = DB_PASS ?? '';
    
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $user,
        $pass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );
    $pdo->exec("SET time_zone = '+01:00'");
} catch (PDOException $e) {
    die('Database connection failed: ' . $e->getMessage());
}

// Handle actions
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $reviewId = (int)($_POST['review_id'] ?? 0);
    
    try {
        if ($action === 'approve' && $reviewId) {
            $stmt = $pdo->prepare("UPDATE product_reviews SET approved = 1 WHERE id = ?");
            $stmt->execute([$reviewId]);
            $message = 'Opinia została zatwierdzona.';
            $messageType = 'success';
        } 
        elseif ($action === 'reject' && $reviewId) {
            $stmt = $pdo->prepare("UPDATE product_reviews SET visible = 0 WHERE id = ?");
            $stmt->execute([$reviewId]);
            $message = 'Opinia została odrzucona.';
            $messageType = 'success';
        }
        elseif ($action === 'delete' && $reviewId) {
            $stmt = $pdo->prepare("DELETE FROM product_reviews WHERE id = ?");
            $stmt->execute([$reviewId]);
            $message = 'Opinia została usunięta.';
            $messageType = 'success';
        }
    } catch (PDOException $e) {
        $message = 'Błąd: ' . $e->getMessage();
        $messageType = 'error';
    }
}

// Get filter
$filter = $_GET['filter'] ?? 'pending';
$page = max(1, (int)($_GET['page'] ?? 1));
$limit = 20;
$offset = ($page - 1) * $limit;

// Build query based on filter
$whereClause = match($filter) {
    'approved' => 'WHERE r.approved = 1 AND r.visible = 1',
    'rejected' => 'WHERE r.visible = 0',
    'all' => 'WHERE 1=1',
    default => 'WHERE r.approved = 0 AND r.visible = 1' // pending
};

// Get reviews
$stmt = $pdo->prepare("
    SELECT 
        r.id,
        r.product_id,
        r.user_id,
        r.rating,
        r.title,
        r.review_text,
        r.helpful_count,
        r.approved,
        r.visible,
        r.created_at,
        u.name as user_name,
        u.email as user_email,
        p.name_pl as product_name
    FROM product_reviews r
    LEFT JOIN users u ON r.user_id = u.id
    LEFT JOIN products p ON r.product_id = p.id
    {$whereClause}
    ORDER BY r.created_at DESC
    LIMIT ? OFFSET ?
");
$stmt->execute([$limit, $offset]);
$reviews = $stmt->fetchAll();

// Get total count
$stmt = $pdo->prepare("
    SELECT COUNT(*) as total
    FROM product_reviews r
    {$whereClause}
");
$stmt->execute();
$totalReviews = $stmt->fetch()['total'];
$totalPages = ceil($totalReviews / $limit);

// Get statistics
$stmt = $pdo->query("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN approved = 0 AND visible = 1 THEN 1 ELSE 0 END) as pending,
        SUM(CASE WHEN approved = 1 AND visible = 1 THEN 1 ELSE 0 END) as approved,
        SUM(CASE WHEN visible = 0 THEN 1 ELSE 0 END) as rejected
    FROM product_reviews
");
$stats = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Moderacja Opinii - SERSOLTEC Admin</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: #f5f5f5;
            color: #333;
            line-height: 1.6;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        
        header {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        header h1 {
            font-size: 28px;
            color: #333;
            margin-bottom: 10px;
        }
        
        .breadcrumb {
            font-size: 14px;
            color: #666;
        }
        
        .breadcrumb a {
            color: #ff9800;
            text-decoration: none;
        }
        
        .breadcrumb a:hover {
            text-decoration: underline;
        }
        
        .message {
            padding: 15px 20px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        
        .message.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .message.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            text-align: center;
        }
        
        .stat-card h3 {
            font-size: 14px;
            color: #666;
            margin-bottom: 10px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .stat-card .number {
            font-size: 36px;
            font-weight: bold;
            color: #ff9800;
        }
        
        .stat-card.pending .number { color: #ff9800; }
        .stat-card.approved .number { color: #4caf50; }
        .stat-card.rejected .number { color: #f44336; }
        
        .filters {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        .filter-btn {
            padding: 10px 20px;
            background: #f5f5f5;
            border: 2px solid #ddd;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
            text-decoration: none;
            color: #333;
        }
        
        .filter-btn:hover {
            background: #e0e0e0;
        }
        
        .filter-btn.active {
            background: #ff9800;
            color: white;
            border-color: #ff9800;
        }
        
        .reviews-table {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .review-card {
            padding: 25px;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .review-card:last-child {
            border-bottom: none;
        }
        
        .review-header {
            display: grid;
            grid-template-columns: 1fr auto;
            gap: 20px;
            margin-bottom: 15px;
        }
        
        .review-info h3 {
            font-size: 18px;
            margin-bottom: 5px;
            color: #333;
        }
        
        .review-meta {
            font-size: 13px;
            color: #666;
        }
        
        .review-meta span {
            margin-right: 15px;
        }
        
        .review-rating {
            text-align: right;
        }
        
        .stars {
            font-size: 24px;
            color: #ff9800;
            display: block;
            margin-bottom: 5px;
        }
        
        .review-body {
            background: #f9f9f9;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 15px;
        }
        
        .review-body h4 {
            font-size: 16px;
            margin-bottom: 10px;
            color: #333;
        }
        
        .review-body p {
            font-size: 14px;
            line-height: 1.6;
            color: #555;
            white-space: pre-wrap;
        }
        
        .review-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 13px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .btn-approve {
            background: #4caf50;
            color: white;
        }
        
        .btn-approve:hover {
            background: #45a049;
        }
        
        .btn-reject {
            background: #ff9800;
            color: white;
        }
        
        .btn-reject:hover {
            background: #f57c00;
        }
        
        .btn-delete {
            background: #f44336;
            color: white;
        }
        
        .btn-delete:hover {
            background: #d32f2f;
        }
        
        .btn-view {
            background: #2196f3;
            color: white;
        }
        
        .btn-view:hover {
            background: #1976d2;
        }
        
        .badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
        }
        
        .badge.pending {
            background: #fff3cd;
            color: #856404;
        }
        
        .badge.approved {
            background: #d4edda;
            color: #155724;
        }
        
        .badge.rejected {
            background: #f8d7da;
            color: #721c24;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            gap: 10px;
            padding: 30px 20px;
            background: white;
            border-radius: 8px;
            margin-top: 20px;
        }
        
        .pagination a,
        .pagination span {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            text-decoration: none;
            color: #333;
        }
        
        .pagination a:hover {
            background: #f5f5f5;
        }
        
        .pagination .active {
            background: #ff9800;
            color: white;
            border-color: #ff9800;
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #999;
        }
        
        .empty-state svg {
            width: 80px;
            height: 80px;
            margin-bottom: 20px;
            opacity: 0.5;
        }
        
        @media (max-width: 768px) {
            .review-header {
                grid-template-columns: 1fr;
            }
            
            .review-rating {
                text-align: left;
            }
            
            .filters {
                flex-direction: column;
            }
            
            .filter-btn {
                width: 100%;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        
        <!-- Header -->
        <header>
            <h1>🔍 Moderacja Opinii</h1>
            <div class="breadcrumb">
                <a href="/admin/">Panel Admina</a> / Opinie Produktów
            </div>
        </header>
        
        <!-- Message -->
        <?php if ($message): ?>
            <div class="message <?php echo $messageType; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>
        
        <!-- Statistics -->
        <div class="stats-grid">
            <div class="stat-card">
                <h3>Wszystkie</h3>
                <div class="number"><?php echo $stats['total']; ?></div>
            </div>
            <div class="stat-card pending">
                <h3>Oczekujące</h3>
                <div class="number"><?php echo $stats['pending']; ?></div>
            </div>
            <div class="stat-card approved">
                <h3>Zatwierdzone</h3>
                <div class="number"><?php echo $stats['approved']; ?></div>
            </div>
            <div class="stat-card rejected">
                <h3>Odrzucone</h3>
                <div class="number"><?php echo $stats['rejected']; ?></div>
            </div>
        </div>
        
        <!-- Filters -->
        <div class="filters">
            <a href="?filter=pending" class="filter-btn <?php echo $filter === 'pending' ? 'active' : ''; ?>">
                Oczekujące (<?php echo $stats['pending']; ?>)
            </a>
            <a href="?filter=approved" class="filter-btn <?php echo $filter === 'approved' ? 'active' : ''; ?>">
                Zatwierdzone (<?php echo $stats['approved']; ?>)
            </a>
            <a href="?filter=rejected" class="filter-btn <?php echo $filter === 'rejected' ? 'active' : ''; ?>">
                Odrzucone (<?php echo $stats['rejected']; ?>)
            </a>
            <a href="?filter=all" class="filter-btn <?php echo $filter === 'all' ? 'active' : ''; ?>">
                Wszystkie (<?php echo $stats['total']; ?>)
            </a>
        </div>
        
        <!-- Reviews List -->
        <div class="reviews-table">
            <?php if (empty($reviews)): ?>
                <div class="empty-state">
                    <svg fill="#999" viewBox="0 0 24 24">
                        <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 2c1.1 0 2 .9 2 2s-.9 2-2 2-2-.9-2-2 .9-2 2-2zM7 18c0-2.67 4-4 5-4s5 1.33 5 4v1H7v-1z"/>
                    </svg>
                    <h3>Brak opinii</h3>
                    <p>Nie znaleziono opinii w tej kategorii.</p>
                </div>
            <?php else: ?>
                <?php foreach ($reviews as $review): ?>
                    <div class="review-card">
                        <div class="review-header">
                            <div class="review-info">
                                <h3><?php echo htmlspecialchars($review['product_name'] ?? 'Nieznany produkt'); ?></h3>
                                <div class="review-meta">
                                    <span><strong>Autor:</strong> <?php echo htmlspecialchars($review['user_name']); ?></span>
                                    <span><strong>Email:</strong> <?php echo htmlspecialchars($review['user_email']); ?></span>
                                    <span><strong>Data:</strong> <?php echo date('d.m.Y H:i', strtotime($review['created_at'])); ?></span>
                                    <span><strong>Pomocne:</strong> <?php echo $review['helpful_count']; ?></span>
                                    <?php
                                    if (!$review['visible']) {
                                        echo '<span class="badge rejected">Odrzucona</span>';
                                    } elseif ($review['approved']) {
                                        echo '<span class="badge approved">Zatwierdzona</span>';
                                    } else {
                                        echo '<span class="badge pending">Oczekująca</span>';
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="review-rating">
                                <div class="stars"><?php echo str_repeat('★', $review['rating']) . str_repeat('☆', 5 - $review['rating']); ?></div>
                                <div style="font-size: 14px; color: #666;">Ocena: <?php echo $review['rating']; ?>/5</div>
                            </div>
                        </div>
                        
                        <div class="review-body">
                            <h4><?php echo htmlspecialchars($review['title']); ?></h4>
                            <p><?php echo nl2br(htmlspecialchars($review['review_text'])); ?></p>
                        </div>
                        
                        <div class="review-actions">
                            <?php if (!$review['approved'] && $review['visible']): ?>
                                <form method="post" style="display: inline;">
                                    <input type="hidden" name="review_id" value="<?php echo $review['id']; ?>">
                                    <input type="hidden" name="action" value="approve">
                                    <button type="submit" class="btn btn-approve" onclick="return confirm('Zatwierdzić tę opinię?')">
                                        ✓ Zatwierdź
                                    </button>
                                </form>
                                <form method="post" style="display: inline;">
                                    <input type="hidden" name="review_id" value="<?php echo $review['id']; ?>">
                                    <input type="hidden" name="action" value="reject">
                                    <button type="submit" class="btn btn-reject" onclick="return confirm('Odrzucić tę opinię?')">
                                        ✗ Odrzuć
                                    </button>
                                </form>
                            <?php endif; ?>
                            
                            <a href="/product-detail.php?id=<?php echo $review['product_id']; ?>" 
                               class="btn btn-view" 
                               target="_blank">
                                👁️ Zobacz produkt
                            </a>
                            
                            <form method="post" style="display: inline;">
                                <input type="hidden" name="review_id" value="<?php echo $review['id']; ?>">
                                <input type="hidden" name="action" value="delete">
                                <button type="submit" class="btn btn-delete" onclick="return confirm('Na pewno usunąć tę opinię? Tej operacji nie można cofnąć.')">
                                    🗑️ Usuń
                                </button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <!-- Pagination -->
        <?php if ($totalPages > 1): ?>
            <div class="pagination">
                <?php if ($page > 1): ?>
                    <a href="?filter=<?php echo $filter; ?>&page=<?php echo $page - 1; ?>">« Poprzednia</a>
                <?php endif; ?>
                
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <?php if ($i == $page): ?>
                        <span class="active"><?php echo $i; ?></span>
                    <?php else: ?>
                        <a href="?filter=<?php echo $filter; ?>&page=<?php echo $i; ?>"><?php echo $i; ?></a>
                    <?php endif; ?>
                <?php endfor; ?>
                
                <?php if ($page < $totalPages): ?>
                    <a href="?filter=<?php echo $filter; ?>&page=<?php echo $page + 1; ?>">Następna »</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        
    </div>
</body>
</html>
