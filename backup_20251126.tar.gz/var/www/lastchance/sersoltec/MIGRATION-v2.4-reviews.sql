-- ================================================================
-- SERSOLTEC v2.4 - Sprint 2.3: Reviews System
-- SQL Migration Script
-- ================================================================
-- This script creates/updates tables needed for the reviews system
-- Safe to run multiple times (uses IF NOT EXISTS)
-- ================================================================

USE sersoltec_db;

-- Set timezone
SET time_zone = '+01:00';

-- ================================================================
-- 1. PRODUCT REVIEWS TABLE
-- ================================================================

CREATE TABLE IF NOT EXISTS `product_reviews` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `product_id` INT NOT NULL,
    `user_id` INT NOT NULL,
    `rating` INT NOT NULL CHECK (`rating` BETWEEN 1 AND 5),
    `title` VARCHAR(255) NOT NULL,
    `review_text` TEXT NOT NULL,
    `helpful_count` INT DEFAULT 0,
    `approved` BOOLEAN DEFAULT 0,
    `visible` BOOLEAN DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    
    INDEX `idx_product` (`product_id`),
    INDEX `idx_user` (`user_id`),
    INDEX `idx_approved` (`approved`),
    INDEX `idx_visible` (`visible`),
    INDEX `idx_rating` (`rating`),
    INDEX `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================================
-- 2. REVIEW HELPFUL TABLE (tracks who marked reviews as helpful)
-- ================================================================

CREATE TABLE IF NOT EXISTS `review_helpful` (
    `review_id` INT NOT NULL,
    `user_id` INT NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    PRIMARY KEY (`review_id`, `user_id`),
    
    FOREIGN KEY (`review_id`) REFERENCES `product_reviews`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    
    INDEX `idx_user` (`user_id`),
    INDEX `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================================
-- 3. REVIEW REPORTS TABLE (optional - for tracking reported reviews)
-- ================================================================

CREATE TABLE IF NOT EXISTS `review_reports` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `review_id` INT NOT NULL,
    `user_id` INT NOT NULL,
    `reason` TEXT NOT NULL,
    `status` ENUM('pending', 'reviewed', 'dismissed') DEFAULT 'pending',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (`review_id`) REFERENCES `product_reviews`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    
    INDEX `idx_review` (`review_id`),
    INDEX `idx_user` (`user_id`),
    INDEX `idx_status` (`status`),
    INDEX `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ================================================================
-- 4. VERIFY REQUIRED TABLES EXIST
-- ================================================================

-- Check if products table exists
SELECT 'Checking products table...' as status;
SELECT COUNT(*) as product_count FROM products;

-- Check if users table exists  
SELECT 'Checking users table...' as status;
SELECT COUNT(*) as user_count FROM users;

-- ================================================================
-- 5. INSERT SAMPLE DATA (optional - for testing)
-- ================================================================

-- Uncomment below to insert sample reviews for testing
/*
-- Sample review 1 (approved)
INSERT INTO product_reviews 
(product_id, user_id, rating, title, review_text, approved, visible, helpful_count)
VALUES 
(1, 1, 5, 'Świetny produkt!', 'Jestem bardzo zadowolony z zakupu. Produkt zgodny z opisem, szybka dostawa. Polecam!', 1, 1, 3);

-- Sample review 2 (approved)
INSERT INTO product_reviews 
(product_id, user_id, rating, title, review_text, approved, visible, helpful_count)
VALUES 
(1, 2, 4, 'Dobra jakość', 'Solidne wykonanie, jedynie cena mogłaby być niższa. Ale ogólnie polecam.', 1, 1, 1);

-- Sample review 3 (pending approval)
INSERT INTO product_reviews 
(product_id, user_id, rating, title, review_text, approved, visible)
VALUES 
(1, 3, 3, 'Przeciętny', 'Nic specjalnego, ale spełnia swoją funkcję.', 0, 1);

-- Sample review 4 (approved)
INSERT INTO product_reviews 
(product_id, user_id, rating, title, review_text, approved, visible, helpful_count)
VALUES 
(2, 1, 5, 'Rewelacja!', 'Najlepszy zakup tego roku! Wszystko działa perfekcyjnie.', 1, 1, 5);
*/

-- ================================================================
-- 6. VERIFICATION QUERIES
-- ================================================================

-- Show table structure
DESCRIBE product_reviews;
DESCRIBE review_helpful;
DESCRIBE review_reports;

-- Count records
SELECT 'product_reviews' as table_name, COUNT(*) as record_count FROM product_reviews
UNION ALL
SELECT 'review_helpful' as table_name, COUNT(*) as record_count FROM review_helpful
UNION ALL
SELECT 'review_reports' as table_name, COUNT(*) as record_count FROM review_reports;

-- Show pending reviews
SELECT 
    r.id,
    r.product_id,
    r.rating,
    r.title,
    r.approved,
    r.visible,
    u.name as user_name,
    p.name_pl as product_name
FROM product_reviews r
LEFT JOIN users u ON r.user_id = u.id
LEFT JOIN products p ON r.product_id = p.id
WHERE r.approved = 0 AND r.visible = 1
ORDER BY r.created_at DESC
LIMIT 10;

-- ================================================================
-- MIGRATION COMPLETE
-- ================================================================

SELECT '✅ Migration completed successfully!' as status;
SELECT 'Review system tables created and ready to use.' as message;
